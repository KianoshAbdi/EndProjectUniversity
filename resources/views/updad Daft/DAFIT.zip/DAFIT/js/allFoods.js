function openNewPage() {
    
    window.open("http://127.0.0.1:5501/persianfood.html");
}